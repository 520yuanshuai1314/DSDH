﻿import importlib.util, sys
mods = ["jieba","gensim","sklearn","scipy","numpy","requests","matplotlib","fitz","pypdf","pdfplumber","bs4","lxml","openpyxl"]
lines = [sys.version]
for m in mods:
    try:
        lines.append(m + ": " + str(bool(importlib.util.find_spec(m))))
    except Exception as e:
        lines.append(m + ": ERR " + str(e))
open(r"D:\2026-11-12-15-41-12\env_probe.txt","w",encoding="utf-8").write("\n".join(lines))
