# -*- coding: utf-8 -*-
"""任务一：主题探索。

预处理 -> TF-IDF -> Gibbs 采样 LDA -> 多组参数对照 -> 原文例句回查。
全部参数与随机种子固定，结果写入 results.json 供报告使用。
"""
import json
import math
import os
import random
import re
from collections import Counter, defaultdict

import jieba
import numpy as np
from opencc import OpenCC

ROOT = r"D:\2026-11-12-15-41-12"
SEED = 20261112
cc = OpenCC("t2s")

# ---------------- 1. 语料 ----------------
docs = [json.loads(l) for l in open(os.path.join(ROOT, "corpus.jsonl"), encoding="utf-8")]
simp = [cc.convert(d["text"]) for d in docs]
print("docs", len(docs), "chars", sum(len(s) for s in simp))

# ---------------- 2. 分词规则 ----------------
USER_WORDS = [
    "新青年", "随感录", "热风", "陈独秀", "李汉俊", "唐俟", "鲁迅",
    "白话文", "白话", "文言文", "古文", "孔教", "礼教", "纲常", "国粹",
    "国故", "旧道德", "新道德", "新文化", "旧文化", "新旧", "调和论",
    "德先生", "赛先生", "民主", "科学", "进化论", "天演论", "达尔文",
    "尼采", "易卜生", "托尔斯泰", "布尔什维克", "过激派", "社会主义",
    "马克思主义", "劳农政府", "无政府主义", "国家主义", "爱国主义",
    "国民性", "中国人", "中国", "社会", "改革", "改良", "革命", "复古",
    "保存国粹", "汉字", "注音字母", "世界语", "Esperanto", "文学革命",
    "思想革命", "道德革命", "伦理", "家族", "孝道", "贞节", "节烈",
    "女子", "妇女", "儿童", "孩子", "青年", "学生", "教育", "学堂",
    "政府", "法律", "言论自由", "自由", "平等", "专制", "共和",
    "日本", "俄国", "德国", "欧战", "世界和平", "侵略", "军国主义",
    "帝国主义", "资本家", "劳动者", "工人", "群众", "平民",
    "迷信", "鬼神", "拳匪", "义和团", "中医", "西医", "科学社",
    "冷笑", "旁观", "麻木", "自大", "奴隶", "奴性", "排外",
]
for w in USER_WORDS:
    jieba.add_word(w, freq=2000)

# 通用停用词：仅虚词、代词、连词、介词、助词、泛化程度词，不含实义内容词
GENERIC = set("""
的 了 着 过 之 乎 者 也 矣 焉 哉 耶 耳 夫 盖 故 是 乃 则 而 且 与 及 或 但 却
虽 然 若 如 倘 假 使 因 为 由 于 以 把 被 从 向 对 给 让 将 在 到 至 于 乎
其 此 彼 这 那 该 本 某 各 每 凡 诸 众 所有 一切 对于 关于 至于 并且 而且
我 你 他 她 它 我们 你们 他们 她们 自己 大家 别人 人家 谁 什么 怎么 怎样
哪 哪里 多少 几 些 个 们 里 中 内 外 上 下 前 后 时 时候 现在 从前 以后
不 没 没有 无 非 未 别 莫 勿 很 太 更 最 极 甚 颇 稍 略 仅 只 就 便 又 再
还 仍 尚 已 曾 正 方 才 将 要 会 能 可 可以 应 该 须 得 着 来 去 有 是
一 二 三 四 五 六 七 八 九 十 半 两 第一 第二 一样 一样地
「 」 『 』 （ ） 《 》 、 ， 。 ？ ！ ； ： … — －
说 说道 所谓 之类 等等 一样 这样 那样 如此 于是 所以 因此 然而 不过
其实 固然 自然 当然 大约 大概 或者 也许 恐怕 未必 一定 实在 本来
一个 一种 一面 一方 一面 一时 一点 一些 有一种 有一 没有一
""".split())

# 语料专属停用词：署名、刊物、栏目、格式套语（防止主题被来源标识/作者名污染）
SPECIFIC = set("""
新青年 随感录 热风 本志 本刊 杂志 鲁迅 唐俟 陈独秀 独秀 李汉俊 汉俊
先生 君 记者 编者 原注 附注 通信 读者论坛 注 注释 按 附识 跋
年 月 日 号 卷 期 页 中华民国 民国
""".split())

# 停用词表 v2：正式建模前，依据「预分词词频 top 150 人工审定」补入的高频功能词。
# 审定标准：仅收连词、副词、代词、助词、泛指动词与序数词；实义内容词一律保留。
# 该审定只依据词频统计，不参考任何 LDA 输出，以保证规则先于结果。
V2_ADD = set("""
因为 不能 不是 如此 许多 便是 就是 对于 一种 看见 一样 这种 自然 还是 只是
虽然 只有 应该 你们 以为 的话 将来 怎样 于是 别人 知道 那里 正是 何以 至于
这是 能够 即使 里面 只能 别的 只要 还要 不知 明白 后来 可是 大约 如何 意思
不要 起来 不会 完全 看来 所说 以至 特别 有人 真是 一件 不但 一般 罢了 究竟
晓得 一句 两种 情形 不必 第三 第四 第五 第六 第七 第八 第九 第十 有些 有个
无非 总之 大概 正是 却是 乃是 不只 不单 并且 以及 或者 倘若 设使 一经
""".split())
GENERIC |= V2_ADD

PUNCT = re.compile(r"^[\W\d_]+$", re.UNICODE)


def tokenize(text, keep_single=False):
    out = []
    for w in jieba.cut(text):
        w = w.strip().lower()
        if not w or PUNCT.match(w):
            continue
        if len(w) < 2 and not keep_single:
            continue
        if w in GENERIC or w in SPECIFIC:
            continue
        out.append(w)
    return out


def tokenize_generic_only(text, keep_single=False):
    out = []
    for raw in jieba.cut(text):
        w = raw.strip().lower()
        if not w or PUNCT.match(w):
            continue
        if len(w) < 2 and not keep_single:
            continue
        if w in GENERIC:
            continue
        out.append(w)
    return out


SETTINGS = [
    {"gid": "G1", "K": 4, "stop": "S2", "seg": "W1", "label": "基准组：K=4 / 通用+专属停用词 / 词级分词"},
    {"gid": "G2", "K": 3, "stop": "S2", "seg": "W1", "label": "对照A：K=3（主题数减少）"},
    {"gid": "G3", "K": 5, "stop": "S2", "seg": "W1", "label": "对照B：K=5（主题数增加）"},
    {"gid": "G4", "K": 4, "stop": "S1", "seg": "W1", "label": "对照C：仅通用停用词（保留署名与刊名）"},
    {"gid": "G5", "K": 4, "stop": "S2", "seg": "W2", "label": "对照D：保留单字词"},
]


def build_tokens(setting):
    fn = tokenize_generic_only if setting["stop"] == "S1" else tokenize
    return [fn(s, keep_single=(setting["seg"] == "W2")) for s in simp]


# ---------------- 3. TF-IDF ----------------
def tfidf(tokens, topn=40):
    D = len(tokens)
    df = Counter()
    tf = []
    for t in tokens:
        c = Counter(t)
        tf.append(c)
        df.update(c.keys())
    idf = {w: math.log((D + 1) / (n + 1)) + 1 for w, n in df.items()}
    vecs = []
    for c in tf:
        v = {w: (1 + math.log(n)) * idf[w] for w, n in c.items()}
        norm = math.sqrt(sum(x * x for x in v.values())) or 1.0
        vecs.append({w: x / norm for w, x in v.items()})
    total = defaultdict(float)
    for v in vecs:
        for w, x in v.items():
            total[w] += x
    global_top = sorted(total.items(), key=lambda x: -x[1])[:topn]
    per_doc = []
    for i, v in enumerate(vecs):
        per_doc.append(sorted(v.items(), key=lambda x: -x[1])[:6])
    return {"global": [{"word": w, "score": round(s, 4), "df": df[w]} for w, s in global_top],
            "per_doc": [[{"word": w, "score": round(s, 4)} for w, s in row] for row in per_doc],
            "vocab_size": len(df)}


# ---------------- 4. Gibbs LDA ----------------
def lda(tokens, K, iters=300, burn=150, thin=5, alpha=0.10, beta=0.01, seed=SEED,
        min_count=2):
    cnt = Counter(w for t in tokens for w in t)
    vocab = sorted([w for w, c in cnt.items() if c >= min_count])
    wid = {w: i for i, w in enumerate(vocab)}
    V = len(vocab)
    words, dids = [], []
    for i, t in enumerate(tokens):
        for w in t:
            if w in wid:
                words.append(wid[w]); dids.append(i)
    D, N = len(tokens), len(words)
    rnd = random.Random(seed)
    z = [rnd.randrange(K) for _ in range(N)]
    nw = [[0] * V for _ in range(K)]
    nd = [[0] * K for _ in range(D)]
    nwsum = [0] * K
    ndsum = [0] * D
    for i in range(N):
        w, d, t = words[i], dids[i], z[i]
        nw[t][w] += 1; nd[d][t] += 1; nwsum[t] += 1; ndsum[d] += 1
    acc = [[0.0] * V for _ in range(K)]
    nsamp = 0
    for it in range(iters):
        for i in range(N):
            w, d, t = words[i], dids[i], z[i]
            nw[t][w] -= 1; nd[d][t] -= 1; nwsum[t] -= 1
            left = [nd[d][k] + alpha for k in range(K)]
            p = [((nw[k][w] + beta) / (nwsum[k] + V * beta)) * left[k] for k in range(K)]
            s = sum(p)
            r = rnd.random() * s
            c = 0.0; nt = K - 1
            for k in range(K):
                c += p[k]
                if r < c:
                    nt = k; break
            z[i] = nt
            nw[nt][w] += 1; nd[d][nt] += 1; nwsum[nt] += 1
        if it >= burn and (it - burn) % thin == 0:
            for i in range(N):
                acc[z[i]][words[i]] += 1.0
            nsamp += 1
    topics = []
    for k in range(K):
        row = acc[k]
        total = sum(row) + V * beta
        top = sorted(range(V), key=lambda j: -row[j])[:15]
        topics.append([{"word": vocab[j], "weight": round((row[j] + beta) / total, 6)} for j in top])
    theta = [[(nd[d][k] + alpha) / (ndsum[d] + K * alpha) for k in range(K)] for d in range(D)]
    dom = [max(range(K), key=lambda k: theta[d][k]) for d in range(D)]
    return {"K": K, "topics": topics, "theta": theta, "dominant": dom,
            "vocab_size": V, "n_tokens": N, "samples": nsamp,
            "params": {"iters": iters, "burn_in": burn, "thin": thin,
                       "alpha": alpha, "beta": beta, "seed": seed, "min_count": min_count}}


def jaccard(a, b):
    sa, sb = set(a), set(b)
    return len(sa & sb) / len(sa | sb) if sa | sb else 0.0


# ---------------- 5. 运行全部设置 ----------------
groups = []
for st in SETTINGS:
    toks = build_tokens(st)
    print(st["gid"], "tokens", sum(len(t) for t in toks))
    res = lda(toks, st["K"])
    groups.append({"setting": st, "n_tokens": sum(len(t) for t in toks),
                   "lda": res,
                   "tfidf": tfidf(toks) if st["gid"] == "G1" else None})
    print("   ", [[x["word"] for x in tp[:6]] for tp in res["topics"]])

base = groups[0]
# 稳定性：每个基准主题在各对照设置中的最佳 Jaccard 匹配
stability = []
for ti, tp in enumerate(base["lda"]["topics"]):
    bw = [x["word"] for x in tp[:10]]
    row = {"topic": ti, "base_words": bw, "matches": {}}
    for g in groups[1:]:
        best = max(((jaccard(bw, [x["word"] for x in t[:10]]), k)
                    for k, t in enumerate(g["lda"]["topics"])), default=(0.0, -1))
        row["matches"][g["setting"]["gid"]] = {"jaccard": round(best[0], 3), "topic": best[1]}
    stability.append(row)

# ---------------- 6. 原文例句回查 ----------------
# 原文按句切分；检索在简体句上进行，展示使用繁体原句
def sentences(text):
    return [s.strip() for s in re.split(r"[。！？；\n]+", text) if len(s.strip()) >= 12]


orig_sents, simp_sents = [], []
for d in docs:
    o = sentences(d["text"])
    s = sentences(simp[docs.index(d)])
    # 简体与繁体切分次数应一致；不一致时按较短者截断，保证对齐
    n = min(len(o), len(s))
    orig_sents.append(o[:n]); simp_sents.append(s[:n])

evidence = []
for ti, tp in enumerate(base["lda"]["topics"]):
    words = [x["word"] for x in tp[:8]]
    hits = []
    for di in range(len(docs)):
        for si, ss in enumerate(simp_sents[di]):
            hit = [w for w in words if w in ss]
            if not hit:
                continue
            score = sum(next((x["weight"] for x in tp if x["word"] == w), 0) for w in hit)
            score *= (1 + 0.35 * (len(hit) - 1))
            hits.append({"score": round(score, 6), "doc": di, "sent": si,
                         "hit": hit, "text": orig_sents[di][si]})
    hits.sort(key=lambda x: -x["score"])
    picked, used_docs = [], set()
    for h in hits:
        if h["doc"] in used_docs and len(picked) >= 2:
            continue
        used_docs.add(h["doc"])
        d = docs[h["doc"]]
        picked.append({"id": d["id"], "title": d["title"], "author": d["author"],
                       "date": d["date"], "hits": h["hit"],
                       "quote": h["text"][:160]})
        if len(picked) == 3:
            break
    evidence.append({"topic": ti, "top_words": words[:8], "examples": picked})

out = {
    "corpus": {"n_docs": len(docs),
               "total_chars": sum(d["n_chars"] for d in docs),
               "authors": dict(Counter(d["author"] for d in docs)),
               "years": dict(Counter(str(d["year"]) for d in docs)),
               "source_types": dict(Counter(d["source_type"] for d in docs))},
    "rules": {"generic_stop": sorted(GENERIC), "specific_stop": sorted(SPECIFIC),
              "user_words": USER_WORDS, "seed": SEED},
    "settings": SETTINGS,
    "groups": groups,
    "stability": stability,
    "evidence": evidence,
    "docs": [{"id": d["id"], "title": d["title"], "author": d["author"],
              "date": d["date"], "year": d["year"], "source_type": d["source_type"],
              "source_page": d["source_page"], "n_chars": d["n_chars"]} for d in docs],
}
with open(os.path.join(ROOT, "results.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print("WROTE results.json", os.path.getsize(os.path.join(ROOT, "results.json")))
