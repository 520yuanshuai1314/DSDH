# -*- coding: utf-8 -*-
"""生成任务一实验报告 HTML（供 Edge headless 转 PDF）。报告正文不含程序代码。"""
import html
import json
import os

ROOT = r"D:\2026-11-12-15-41-12"
r = json.load(open(os.path.join(ROOT, "results.json"), encoding="utf-8"))
pilot = json.load(open(os.path.join(ROOT, "results_pilot.json"), encoding="utf-8"))
docs = r["docs"]
base = r["groups"][0]
tf = base["tfidf"]["global"]
topics = base["lda"]["topics"]
params = base["lda"]["params"]
ev = r["evidence"]
stab = r["stability"]
V2_ADD = None

CSS = """
@page { size: A4; margin: 19mm 17mm 17mm; }
* { box-sizing: border-box; }
body { margin:0; background:#FBFBFD; color:#1D1D1F;
  font-family:'PingFang SC','Microsoft YaHei','Source Han Sans SC','Noto Sans CJK SC',sans-serif;
  font-weight:400; font-size:10.2pt; line-height:1.86; -webkit-print-color-adjust:exact; }
.topline { display:flex; height:3px; width:100%; }
.topline i { display:block; flex:1; }
.wrap { padding:0 0 14mm; }
h1 { font-size:25pt; font-weight:300; line-height:1.28; letter-spacing:-0.5px; margin:0 0 14px; }
h2 { font-size:15pt; font-weight:400; margin:30px 0 12px; padding-bottom:8px;
  border-bottom:0.5px solid rgba(0,0,0,0.12); page-break-after:avoid; }
h3 { font-size:11.5pt; font-weight:400; margin:20px 0 8px; color:#1D1D1F; page-break-after:avoid; }
p { margin:0 0 10px; }
.eyebrow { font-size:8.4pt; letter-spacing:0.46em; color:#86868B; margin-bottom:16px; }
.sub { color:#6E6E73; font-size:11pt; line-height:1.7; }
.muted { color:#6E6E73; }
.hint { color:#86868B; font-size:8.8pt; line-height:1.6; }
.cover { padding-top:26mm; page-break-after:always; }
.cover .meta { margin-top:34mm; }
.kv { width:100%; font-size:9.6pt; border-collapse:collapse; }
.kv td { padding:7px 0; border-bottom:0.5px solid rgba(0,0,0,0.10); vertical-align:top; }
.kv td:first-child { width:27%; color:#6E6E73; }
table { width:100%; border-collapse:collapse; font-size:9pt; margin:10px 0 14px;
  page-break-inside:auto; }
th { font-weight:400; color:#6E6E73; text-align:left; padding:6px 8px;
  border-bottom:0.5px solid rgba(0,0,0,0.16); background:rgba(0,0,0,0.015); }
td { padding:5px 8px; border-bottom:0.5px solid rgba(0,0,0,0.075); vertical-align:top;
  line-height:1.6; }
tr { page-break-inside:avoid; }
.num { text-align:right; font-variant-numeric:tabular-nums; }
.quote { border-left:2px solid rgba(0,122,255,0.45); padding:2px 0 2px 12px;
  margin:7px 0 10px; font-size:9.4pt; line-height:1.78; color:#1D1D1F; }
.src { color:#86868B; font-size:8.4pt; }
.box { background:rgba(0,122,255,0.035); border:0.5px solid rgba(0,122,255,0.16);
  border-radius:8px; padding:12px 15px; margin:12px 0 16px; font-size:9.6pt; }
.tag { display:inline-block; color:#6E6E73; font-size:8.4pt; letter-spacing:0.05em;
  border:0.5px solid rgba(0,0,0,0.14); border-radius:20px; padding:1px 9px; margin-right:6px; }
.words { color:#1D1D1F; font-size:9.6pt; line-height:1.9; }
ul { margin:6px 0 12px; padding-left:19px; }
li { margin-bottom:5px; }
.formula { background:rgba(0,0,0,0.022); border-radius:6px; padding:9px 13px;
  font-size:9.6pt; color:#1D1D1F; margin:8px 0 12px; }
.appx { height:0; }
.footer { color:#86868B; font-size:8.4pt; border-top:0.5px solid rgba(0,0,0,0.10);
  padding-top:8px; margin-top:24px; }
"""


def esc(s):
    return html.escape(str(s), quote=True)


def table(headers, rows, aligns=None):
    aligns = aligns or []
    th = "".join("<th%s>%s</th>" % (
        ' class="num"' if i < len(aligns) and aligns[i] == "r" else "", esc(h))
        for i, h in enumerate(headers))
    body = []
    for row in rows:
        tds = "".join("<td%s>%s</td>" % (
            ' class="num"' if i < len(aligns) and aligns[i] == "r" else "", c)
            for i, c in enumerate(row))
        body.append("<tr>%s</tr>" % tds)
    return "<table><thead><tr>%s</tr></thead><tbody>%s</tbody></table>" % (th, "".join(body))


P = []
P.append("<!DOCTYPE html><html lang='zh-CN'><head><meta charset='utf-8'><style>%s</style></head><body>" % CSS)
P.append("<div class='topline'><i style='background:#007AFF'></i><i style='background:#AF52DE'></i>"
         "<i style='background:#FF2D55'></i><i style='background:#FF9500'></i></div>")
P.append("<div class='wrap'>")

# ---------------- 封面 ----------------
P.append("<div class='cover'>")
P.append("<div class='eyebrow'>4.7 综合实践 · 任务一</div>")
P.append("<h1>《新青年》「随感录」专题文本<br>主题探索实验报告</h1>")
P.append("<p class='sub'>基于 38 篇公有领域文本的 TF-IDF 关键词提炼、LDA 候选主题建模、"
         "原文例句回查与参数稳定性对照</p>")
P.append("<div class='meta'>")
P.append(table(["项目", "内容"], [
    ["课程任务", "4.7 综合实践：主题探索与作者文本对比 · 任务一「探索语料中的主题」"],
    ["语料", "《新青年》「随感录」专栏专题文本 38 篇，共 28,067 字（繁体原文）"],
    ["年代范围", "1918-09-15 — 1921-05-01（另有 1 篇元数据标 1925，见 2.2）"],
    ["作者构成", "鲁迅 27 篇、陈独秀 7 篇、李汉俊 4 篇"],
    ["方法", "TF-IDF 权重排序；Gibbs 采样 LDA；5 组参数对照；原文例句回查"],
    ["语料来源", "维基文库 zh.wikisource.org（公有领域），MediaWiki raw 接口，抓取于 2026-11-12"],
    ["报告日期", "2026 年 11 月 12 日"],
]))
P.append("</div>")
P.append("<p class='hint' style='margin-top:26mm'>说明：引文一律照录维基文库繁体原文；"
         "用于统计分析的文本经繁简转换后处理。本报告正文不含程序代码，全部参数与规则以表格形式记录，"
         "可据以复现。</p>")
P.append("</div>")

# ---------------- 一 ----------------
P.append("<h2>一、实验目的与任务边界</h2>")
P.append("<p>本实验要求在同一总集、报刊专栏或档案专题中选取 10–50 篇文本，完成分词与停用词处理，"
         "以 TF-IDF 或 LDA 提炼关键词与候选主题，列出各主题高权重词，回到原文抽查例句，"
         "并判断这些词能否形成有证据支持的解释；同时记录 LDA 主题数与停用词设置，比较不同设置下结果是否稳定。</p>")
P.append("<p>据此，本报告的核心产出不是一张主题词表，而是一条可复核的证据链："
         "<span class='muted'>语料来源与收录标准 → 建模前定稿的预处理规则 → 参数与随机种子 → 统计结果 → 原文例句 → 解释成立与否的判断 → 稳定性检验</span>。</p>")
P.append("<div class='box'>任务边界：本报告仅覆盖任务一。因题目说明两项任务可共用同一批材料，"
         "语料在选取时已预留任务二「作者文本对比」的条件——同一专栏内保留三位署名作者且每人有多篇文本。"
         "该设计同时带来一个需在结果中控制的变量：作者分布不均（鲁迅占 27/38），见 2.5 与 6.3。</div>")

# ---------------- 二 ----------------
P.append("<h2>二、语料构建与来源登记</h2>")
P.append("<h3>2.1 来源、许可与获取方式</h3>")
P.append("<p>语料取自维基文库（zh.wikisource.org）收录的《新青年》「随感录」专栏专题文本，"
         "为已进入公有领域的近代期刊文献：《新青年》1918–1921 年刊行，相关作者逝世均逾 50 年，"
         "维基文库该批条目按公有领域发布。获取方式为 MediaWiki <span class='muted'>index.php?action=raw</span> 原始文本接口，"
         "本机直连（不经代理），抓取日期 2026-11-12；逐页原始文本缓存于 raw_pages/ 目录，可复核。</p>")
P.append(table(["来源类型", "维基文库条目形式", "篇数", "说明"], [
    ["期刊原刊页", "新青年/第07卷/第1號/隨感錄 等 3 页", "11", "按页内 ==小标题== 拆为独立各则，标题括号内署名作为作者"],
    ["结集重收本", "熱風/隨感錄/二十五 … 六十六，共 27 页", "27", "鲁迅以笔名「唐俟」原载《新青年》该栏，后收入《热风》；页首含作者、年月日、from=新青年"],
    ["合计", "—", "38", "两组均属同一专栏专题文本"],
], ["", "", "r", ""]))
P.append("<p class='hint'>别名条目（如 新青年/卷7/1號/隨感錄）经核验为重定向页，未重复收录；"
         "卷目录页、题记、注释页及无正文页均排除。</p>")

P.append("<h3>2.2 年代范围</h3>")
P.append("<p>有效年代为 1918 年 9 月至 1921 年 5 月，按维基文库页首元数据登记的分布为："
         "1918 年 5 篇、1919 年 24 篇、1920 年 2 篇、1921 年 6 篇。"
         "另有 1 篇（A02《随感录·三十三》）元数据标为 1925-09-24，与该专栏刊行期及《热风》结集时间不符，"
         "疑为维基文库录入误差。<span class='muted'>本报告保留原始元数据值并在附录 A 标注，不擅自改写，"
         "但在年代统计与讨论中将其视为存疑项单独说明。</span></p>")

P.append("<h3>2.3 收录标准（建模前确定）</h3>")
P.append("<ul>"
         "<li>主题同一性：文本须属于《新青年》「随感录」专栏专题，或为该栏文章的后出结集重收本；不混入同期其他栏目。</li>"
         "<li>篇章单位：以具有独立标题（或独立编号）的一则为 1 篇；期刊原刊页按页内小标题拆分。</li>"
         "<li>完整性：正文不少于 12 字的段落构成文本；空页、重定向页、目录页排除。</li>"
         "<li>规模：38 篇，落在题目要求的 10–50 篇区间；单篇 294–2,284 字，合计 28,067 字。</li>"
         "<li>可追溯：每篇登记编号、篇题、作者、日期、来源类型、维基文库条目名与字数（附录 A）。</li>"
         "</ul>")

P.append("<h3>2.4 语料构成摘要</h3>")
P.append(table(["维度", "分布"], [
    ["作者", "鲁迅 27 篇（71.1%）、陈独秀 7 篇（18.4%）、李汉俊 4 篇（10.5%）"],
    ["来源类型", "结集重收本 27 篇（71.1%）、期刊原刊页 11 篇（28.9%）"],
    ["年代", "1918:5 / 1919:24 / 1920:2 / 1921:6 / 1925（存疑）:1"],
    ["篇幅", "最短 294 字，最长 2,284 字，平均 739 字"],
]))

P.append("<h3>2.5 已知局限（先行记录）</h3>")
P.append("<ul>"
         "<li><span class='muted'>版本差异</span>：结集重收本可能经作者修订，与期刊原刊并非同一版本；两类文本的标点、用字数字化规范亦不完全一致。</li>"
         "<li><span class='muted'>作者分布不均</span>：鲁迅占 27/38，语料的词汇分布必然偏向其用语习惯，LDA 主题可能混入作者风格而非纯议题差异。</li>"
         "<li><span class='muted'>小样本</span>：38 篇、有效词元 6,690 个，对 LDA 属小样本，结论应按「候选主题」表述。</li>"
         "</ul>")

# ---------------- 三 ----------------
P.append("<h2>三、预处理规则（建模前定稿）</h2>")
P.append("<p>以下规则在正式建模之前一次性写入记录，不依据 LDA 输出反向调整。全部文本先做繁简转换，"
         "统计用简体文本；例句回查仍引用繁体原文。</p>")
P.append(table(["环节", "规则", "依据与说明"], [
    ["繁简转换", "OpenCC t2s 逐篇转换", "jieba 词典为简体；不转换会把繁体词切成单字"],
    ["分词", "jieba 精确模式 + 自定义词典 %d 条" % len(r["rules"]["user_words"]),
     "收录新文化运动专名与术语：国粹、旧道德、新文化、调和论、社会主义、过激派、布尔什维克、"
     "言论自由、国民性、美术家、泼克、bolsheviki 等，避免被误切"],
    ["通用停用词 S1", "虚词、代词、连词、介词、助词、泛指动词、序数词", "仅停纯功能词，实义内容词一律保留"],
    ["专属停用词 S2", "S1 + 署名、刊名、栏目名、格式套语（鲁迅／唐俟／陈独秀／李汉俊、新青年、随感录、热风、本志、先生、记者、原注等）",
     "防止主题被来源标识与作者名污染"],
    ["过滤", "词长 ≥ 2（W1）；去纯数字与标点；LDA 词表 min_count = 2", "W2 对照组放宽至词长 ≥ 1"],
]))
P.append("<h3>3.1 停用词表 v1 → v2 的预检修订</h3>")
P.append("<p>正式建模前先做一次<span class='muted'>词频预检</span>：对全语料分词后取词频前 150 位人工审定，"
         "发现初版通用表漏收了「因为、不能、不是、许多、便是、看见、的话、只是、虽然、这种、第四」等高频功能词。"
         "据此补入 <b style='font-weight:400'>%d</b> 项纯功能词形成 v2 并定稿；"
         "国粹、旧道德、社会主义、进化、自大、鬼话、偶像、美术家、泼克等实义词全部保留。</p>"
         % (len(set(r["rules"]["generic_stop"]) - set(pilot["rules"]["generic_stop"]))))
P.append("<div class='box'>该修订的依据是<strong style='font-weight:400'>词频统计</strong>，"
         "不是任何 LDA 输出——预跑结果仅作为过程记录留存，未纳入正式结果或对照表。"
         "这保证了「规则先于结果」，避免事后调参。</div>")
P.append("<p class='hint'>对照意义：预跑（v1）时 TF-IDF 前 30 位中有 13 项为功能词，"
         "LDA 主题出现「的话、便是、虽然、许多」；定稿（v2）后这些词退出高权重区，"
         "实义议题词进入前列。该差异本身即说明停用词设置对结果的影响量级。</p>")

# ---------------- 四 ----------------
P.append("<h2>四、方法与参数记录</h2>")
P.append("<h3>4.1 TF-IDF</h3>")
P.append("<div class='formula'>词频 tf = 1 + ln(n<sub>w,d</sub>)　｜　逆文档频率 idf = ln[(N+1)/(df+1)] + 1　｜　"
         "权重 = tf × idf，按文档作 L2 归一化；全局排序取各文档归一化权重之和。</div>")
P.append("<p class='hint'>N = 38 篇；df 为该词出现的文档数。TF-IDF 输出的是<span class='muted'>区分性词</span>，"
         "不等于主题；本报告用它交叉检查 LDA 高权重词是否确为语料中的显著用语。</p>")

P.append("<h3>4.2 LDA（Gibbs 采样，自行实现）</h3>")
P.append(table(["参数", "取值", "说明"], [
    ["主题数 K", "基准 4；对照 3、5", "小样本下不宜取更大 K"],
    ["迭代次数", str(params["iters"]), "burn-in %d，之后每 %d 次采样一次，累计 %d 次样本" % (params["burn_in"], params["thin"], base["lda"]["samples"])],
    ["α（文档-主题先验）", str(params["alpha"]), "对称先验"],
    ["β（主题-词先验）", str(params["beta"]), "对称先验"],
    ["随机种子", str(params["seed"]), "固定，保证可复现"],
    ["词表下限", "min_count = %d" % params["min_count"], "过滤仅在 1 篇中出现 1 次的孤立词"],
    ["有效词元", "%d（基准组）" % base["n_tokens"], "词表规模 %d" % base["lda"]["vocab_size"]],
]))
P.append("<p class='hint'>采样公式：对每个词元，按 (n<sub>k,w</sub>+β)/(n<sub>k</sub>+Vβ) × (n<sub>d,k</sub>+α) "
         "计算各主题条件概率并重新抽样；累积 burn-in 之后各次样本的主题-词分配作为 φ，文档-主题分布为 θ。</p>")

P.append("<h3>4.3 五组设置对照</h3>")
rows = []
for s in r["settings"]:
    g = next(x for x in r["groups"] if x["setting"]["gid"] == s["gid"])
    rows.append([s["gid"], s["label"], "K=%d" % s["K"], s["stop"], s["seg"], str(g["n_tokens"])])
P.append(table(["组", "设置说明", "主题数", "停用词", "分词", "有效词元"], rows, ["", "", "", "", "", "r"]))
P.append("<p class='hint'>S1 = 仅通用停用词；S2 = 通用 + 语料专属停用词；"
         "W1 = 词级（词长 ≥ 2）；W2 = 保留单字。稳定性以基准组各主题前 10 词与对照组的"
         "最佳 Jaccard 相似度衡量。</p>")

P.append("<h3>4.4 独立算法交叉验证（未完成，记为局限）</h3>")
P.append("<p>原计划用 scikit-learn 1.9.1 的变分 EM 实现（n_components=4，max_iter=500，"
         "doc_topic_prior=0.1，topic_word_prior=0.01，random_state=20261112）重跑基准组，"
         "以检验主题是否依赖具体算法实现。实际执行时其编译扩展被本机应用控制策略拦截"
         "（导入报错：DLL load failed），无法加载。<span class='muted'>故本报告的稳定性结论"
         "仅基于同一 Gibbs 实现下的五组参数对照，未包含跨算法验证。</span>这是方法上的一项明确局限，"
         "不绕过系统策略，也不以其他方式替代。</p>")

# ---------------- 五 ----------------
P.append("<h2>五、结果</h2>")
P.append("<h3>5.1 TF-IDF 全局高权重词（基准组，前 20）</h3>")
P.append(table(["序", "词", "权重", "df", "序", "词", "权重", "df"],
               [[str(i + 1), esc(tf[i]["word"]), "%.4f" % tf[i]["score"], str(tf[i]["df"]),
                 str(i + 11), esc(tf[i + 10]["word"]), "%.4f" % tf[i + 10]["score"], str(tf[i + 10]["df"])]
                for i in range(10)], ["r", "", "r", "r", "r", "", "r", "r"]))
P.append("<p>「中国」（df=27）「社会」（df=19）几乎贯穿全语料，属<span class='muted'>底色词</span>而非区分性主题；"
         "「景象」「实业」df 仅 2，权重高是因为集中在个别篇章，属<span class='muted'>篇章特异词</span>。"
         "两者都不能单独作为主题证据。真正有解释潜力的是 df 居中且语义明确的"
         "「国粹」「社会主义」「道德」「文化」「主义」「思想」「美术家」等，"
         "它们与 5.2 的 LDA 高权重词有明显交集，构成一次交叉验证。</p>")

P.append("<h3>5.2 LDA 基准组（G1：K=4 / S2 / W1）候选主题</h3>")
for k, tp in enumerate(topics):
    P.append("<p><span class='tag'>T%d</span><span class='words'>%s</span></p>" % (
        k + 1, " · ".join(esc(x["word"]) for x in tp[:12])))
P.append(table(["主题", "前 6 词权重", "主导文档数"], [
    ["T%d" % (k + 1), "；".join("%s %.4f" % (esc(x["word"]), x["weight"]) for x in tp[:6]),
     str(base["lda"]["dominant"].count(k))]
    for k, tp in enumerate(topics)], ["", "", "r"]))
P.append("<p class='hint'>主导文档数按 θ 最大分量统计，分布为 11 / 7 / 11 / 9，未出现空主题或单篇独占主题。</p>")

P.append("<h3>5.3 回到原文：逐主题例句抽查与证据判断</h3>")
P.append("<p class='hint'>下列例句按「主题词命中权重」从全语料句中检索，每主题取 3 例；"
         "引文照录繁体原文，方括号内为转简体后命中的主题词。</p>")

JUDGE = [
    ("部分成立 · 需拆分", "T1 科学 / 中国人 / 美术家 / 法律 / 泼克 / 美术 / 文明 / 艺术",
     "前 6 词中「美术家、泼克、美术、艺术、讽刺画」在 A16《随感录·四十三》、A12 中稳定同现，"
     "可命名为「新艺术与《泼克》讽刺画之争」，证据明确。但「科学、法律、言论自由、文明」主要来自"
     "陈独秀《法律与言论自由》（B01）等另一组文本，与美术议题并无同篇共现。"
     "判断：LDA 在小样本下把两个不相干的低频议题合并进同一主题，该主题不能作为一个统一解释成立，"
     "只能拆为两个各自有例句支持的候选子议题。这是「高权重词 ≠ 有证据的解释」的直接反例。"),
    ("成立", "T2 人类 / 中国 / 社会 / 理想 / 经验 / 道德 / 国粹 / 新旧 / 旧道德",
     "B03《调和论与旧道德》中「道德革新、旧道德、人类、社会、理想」在同一段内反复同现，"
     "「新旧、调和、进化、保存国粹」亦属该篇的论争脉络，可命名为「新旧道德论争与社会理想」，证据充分。"
     "需降权的是「经验／理想」：它们在 A07 中指个人阅历与「理想的住家」，语义与伦理论争不同，"
     "属跨议题多义词，不宜作为主题命名的主要依据。"),
    ("成立 · 含伴随词", "T3 中国 / 主义 / 思想 / 日本 / 孩子 / 昏乱 / 民族 / 自大",
     "A06「你说中国思想昏乱，那正是我民族所造成的事业的结晶」与 A21「我们中国本不是发生新主义的地方……"
     "外来思想也立刻变了颜色」构成直接证据，可命名为「国民性批判与外来主义的中国处境」。"
     "「孩子、希望、进步」来自《随感录·二十五》关于儿童与将来的议题，属相邻但不同层面；"
     "「日本」多为比较对象而非论旨。这些应标注为伴随词，命名聚焦「思想／主义／昏乱／民族／自大」。"),
    ("成立 · 证据最完整", "T4 运动 / 文化 / 社会 / 阶级 / 外国 / 中国 / 社会主义 / 政治",
     "B10《文化运动与社会运动》篇题与首句「文化运动与社会运动本来是两件事」直接对应主题词，"
     "B08 李汉俊论第四阶级与社会主义亦同篇多词同现。可命名为「文化运动与社会运动之分、阶级与社会主义议题」。"
     "四组中该主题的高权重词与例句同现最充分，且能对应明确篇题，解释力最强。"),
]
for k, e in enumerate(ev):
    verdict, label, judge = JUDGE[k]
    P.append("<h3>%s　<span class='muted' style='font-size:9.5pt'>%s</span></h3>" % (label, ""))
    P.append("<p class='src'>证据判断：%s</p>" % esc(verdict))
    for q in e["examples"]:
        P.append("<div class='quote'>%s<div class='src'>—— %s《%s》，%s，%s　［%s］</div></div>" % (
            esc(q["quote"]), esc(q["author"]), esc(q["title"]), esc(q["date"]),
            esc(q["id"]), "、".join(esc(w) for w in q["hits"])))
    P.append("<p>%s</p>" % esc(judge))

P.append("<div class='box'>小结：四个候选中，T2、T3、T4 能在原文找到同句或同段共现的强证据，"
         "T1 只有一半成立。词表本身不是结论；能否命名出一个由例句支撑的论旨，才是判断标准。</div>")

P.append("<h3>5.4 参数稳定性对照</h3>")
rows = []
for s in stab:
    rows.append(["T%d" % (s["topic"] + 1)] +
                ["%.3f" % s["matches"][g]["jaccard"] for g in ["G2", "G3", "G4", "G5"]] +
                [" ".join(esc(w) for w in s["base_words"][:5])])
P.append(table(["基准主题", "G2 K=3", "G3 K=5", "G4 停用词放宽", "G5 保留单字", "基准前 5 词"], rows,
               ["", "r", "r", "r", "r", ""]))
P.append("<p>观察要点：</p><ul>"
         "<li>主题数变化：T1 在 K=3 时 J=0.538（被并入更大的主题），K=5 时降至 0.250；"
         "T4 在 K=3/5 与各对照组保持 0.333–0.429，是相对最稳定的一组。</li>"
         "<li>停用词放宽（G4）：J 为 0.250–0.429，署名与刊名重新进入词表，但核心议题词仍在，"
         "说明 S2 的专属停用词主要影响噪声量而非议题骨架。</li>"
         "<li>分词粒度（G5）：全部主题的 J 降至 0.176–0.250，「么、都、做、著、和、事、人」等功能字占据高权重，"
         "主题可解释性显著下降——五个设置中影响最大的是分词粒度。</li>"
         "<li>跨组平均 J ≈ 0.30；反复复现的核心词为「中国、社会、文化、运动、思想、主义、道德、人类」。</li>"
         "</ul>")
P.append("<p><span class='muted'>稳定性结论</span>：结果在<span class='muted'>词汇层面稳定</span>，"
         "在<span class='muted'>主题边界层面不稳定</span>。改 K 或改分词，词的集合大体保留，"
         "但主题之间的配对关系会重组（T1 的合并即其表现）。因此本报告将结果表述为「候选主题」，"
         "不宣称已发现确定的主题结构；若换一批停用词或换语料版本，主题划分不应被当作固定结论。</p>")

# ---------------- 六 ----------------
P.append("<h2>六、讨论</h2>")
P.append("<h3>6.1 量化结果不等于解释</h3>")
P.append("<p>T1 是本次实验最有用的结果：它同时给出一个证据充分的子议题（美术与《泼克》之争）"
         "和一个被算法硬合并且无共现证据的词组（科学、法律、言论自由）。"
         "若只交词表并强行命名，就会得到一个看似合理、实则无文本支撑的主题。</p>")
P.append("<h3>6.2 TF-IDF 与 LDA 的分工</h3>")
P.append("<p>TF-IDF 回答「哪些词在这批文本里最具区分性」，LDA 回答「哪些词倾向于共同出现」。"
         "本实验中两者在「国粹、社会主义、道德、文化、主义、思想」上相互印证，"
         "但 TF-IDF 的高权重词「景象、实业」并未进入任何主题，"
         "说明低文档频次的特异词可以权重很高，却不足以构成主题。</p>")
P.append("<h3>6.3 作者风格污染</h3>")
P.append("<p>鲁迅占 27/38，T3 的「昏乱、自大、孩子」等词带有明显的个人用语特征，"
         "因此不能排除该主题部分由作者风格而非议题驱动。S2 已停用署名，但无法停用风格本身。"
         "这一点对任务二尤为重要：若用同批语料做作者文本对比，"
         "本报告的候选主题词应作为协变量加以控制，否则作者分类可能只是在识别议题偏好。</p>")
P.append("<h3>6.4 方法局限汇总</h3>")
P.append("<ul><li>38 篇、6,690 有效词元属 LDA 小样本，K=4 的划分对随机种子与迭代次数敏感。</li>"
         "<li>两类来源存在版本差异（原刊 vs 结集重收）。</li>"
         "<li>1 篇年代元数据存疑，未纳入年代讨论。</li>"
         "<li>跨算法交叉验证因本机应用控制策略未能完成，稳定性仅在同一实现内部检验。</li>"
         "<li>繁简转换与 jieba 分词对近代白话文的兼类词、音译词（如 bolsheviki）仍有切分误差。</li></ul>")

# ---------------- 七 ----------------
P.append("<h2>七、结论</h2>")
P.append("<p>1. 在 38 篇《新青年》「随感录」专题文本中，TF-IDF 与 LDA 共同指向四组候选议题："
         "新旧道德论争与社会理想（T2）、国民性批判与外来主义的中国处境（T3）、"
         "文化运动与社会运动及阶级／社会主义（T4），以及新艺术与《泼克》讽刺画之争（T1 的有效部分）。</p>")
P.append("<p>2. 回到原文抽查后，T2、T3、T4 得到同句或同段共现的例句支持；"
         "T1 的「科学／法律／言论自由」与美术议题无同篇共现，作为一个统一主题不成立，应拆分。</p>")
P.append("<p>3. 五组参数对照显示：核心议题词稳定复现，但主题边界随 K 值、停用词与分词粒度重组；"
         "其中保留单字使全部主题相似度降至 0.176–0.250，影响最大。</p>")
P.append("<p>4. 因此本实验的结论应限定为「有证据支持的候选主题」，"
         "而非对语料主题结构的确定描述；小样本、作者分布不均与版本差异均需在引用结论时一并说明。</p>")

# ---------------- 附录 ----------------
P.append("<div class='appx'></div><h2>附录 A　语料清单（38 篇）</h2>")
P.append("<p class='hint'>来源类型：A＝结集重收本（《热风》）；B＝期刊原刊页（《新青年》）。"
         "标 ※ 者年代元数据存疑。</p>")
rows = []
for d in docs:
    star = " ※" if d["year"] >= 1922 else ""
    rows.append([esc(d["id"]), esc(d["title"]), esc(d["author"]), esc(d["date"]) + star,
                 esc(d["source_type"]), str(d["n_chars"])])
P.append(table(["编号", "篇题", "作者", "日期", "来源类型", "字数"], rows,
               ["", "", "", "", "", "r"]))

P.append("<h2>附录 B　停用词与分词规则记录</h2>")
P.append(table(["项目", "内容"], [
    ["通用停用词表 v2", "共 %d 项；含虚词、代词、连词、介词、助词、泛指动词、序数词" % len(r["rules"]["generic_stop"])],
    ["v2 相对 v1 增补", "%d 项，依据词频前 150 位人工审定，仅补纯功能词" %
     (len(set(r["rules"]["generic_stop"]) - set(pilot["rules"]["generic_stop"])))],
    ["语料专属停用词", "共 %d 项：署名／笔名、刊名、栏目名、格式套语" % len(r["rules"]["specific_stop"])],
    ["自定义词典", "共 %d 条新文化运动专名与术语" % len(r["rules"]["user_words"])],
    ["随机种子", str(r["rules"]["seed"])],
    ["代表例（专属表）", "鲁迅、唐俟、陈独秀、李汉俊、新青年、随感录、热风、本志、先生、记者、原注、附注、通信"],
]))

P.append("<h2>附录 C　完整参数记录</h2>")
P.append(table(["组", "K", "停用词", "分词", "有效词元", "迭代", "burn-in", "thin", "α", "β", "种子"],
               [[s["gid"], str(s["K"]), s["stop"], s["seg"],
                 str(next(x for x in r["groups"] if x["setting"]["gid"] == s["gid"])["n_tokens"]),
                 str(params["iters"]), str(params["burn_in"]), str(params["thin"]),
                 str(params["alpha"]), str(params["beta"]), str(params["seed"])]
                for s in r["settings"]], ["", "r", "", "", "r", "r", "r", "r", "r", "r", "r"]))
P.append("<p class='hint'>全部设置共用同一词表下限 min_count=2、同一随机种子与同一迭代配置；"
         "差异仅限表中列出的 K、停用词版本与分词粒度。</p>")

P.append("<h2>附录 D　来源与可复现信息</h2>")
P.append(table(["项目", "记录"], [
    ["数据源", "维基文库 zh.wikisource.org（公有领域）"],
    ["接口", "https://zh.wikisource.org/w/index.php?title=条目名&action=raw"],
    ["条目枚举", "MediaWiki API list=allpages，前缀「熱風/隨感錄」与「新青年/」"],
    ["抓取日期", "2026-11-12（本机直连，不经代理）"],
    ["原始文本缓存", "raw_pages/（逐条目原始 wikitext）"],
    ["语料清单", "corpus_manifest.csv、corpus.jsonl"],
    ["分析记录", "results.json；预检过程记录 results_pilot.json"],
    ["繁简转换", "OpenCC t2s"],
    ["分词", "jieba 精确模式 + 自定义词典"],
    ["主题模型", "Gibbs 采样 LDA（自行实现）；参数见附录 C"],
]))
P.append("<div class='footer'>《新青年》「随感录」专题文本主题探索实验报告 · 4.7 综合实践任务一 · 2026-11-12</div>")

P.append("</div></body></html>")

out = os.path.join(ROOT, "report.html")
with open(out, "w", encoding="utf-8") as f:
    f.write("\n".join(P))
print("WROTE", out, os.path.getsize(out))
