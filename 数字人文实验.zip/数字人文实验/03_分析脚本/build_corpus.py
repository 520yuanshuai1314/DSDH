# -*- coding: utf-8 -*-
"""构建《新青年》「隨感錄」专栏专题语料。

来源：维基文库（zh.wikisource.org）公有领域数字文本。
两组条目：
  A. 《热风》「隨感錄」单篇页（鲁迅，原载《新青年》随感录栏，后结集重收）
  B. 《新青年》卷7/1号、卷7/2号、卷9/1号「隨感錄」原刊页（陈独秀、李汉俊）
输出：corpus.jsonl（逐篇文本与元数据）、corpus_manifest.csv（来源清单）
原文保留繁体，例句回查使用原文；简体转换在 analyze.py 中完成。
"""
import csv
import json
import os
import re
import subprocess

ROOT = r"D:\2026-11-12-15-41-12"
RAW = os.path.join(ROOT, "raw_pages")
os.makedirs(RAW, exist_ok=True)
LOG = []


def fetch(title, cache):
    path = os.path.join(RAW, cache + ".txt")
    if os.path.exists(path) and os.path.getsize(path) > 80:
        with open(path, encoding="utf-8", errors="replace") as f:
            return f.read()
    cmd = [
        "curl", "-sS", "-m", "45", "--noproxy", "*", "-G",
        "https://zh.wikisource.org/w/index.php",
        "--data-urlencode", "title=" + title,
        "--data-urlencode", "action=raw", "-o", path,
    ]
    subprocess.run(cmd, check=False, capture_output=True)
    if not os.path.exists(path):
        LOG.append("FETCH FAILED: " + title)
        return ""
    with open(path, encoding="utf-8", errors="replace") as f:
        return f.read()


def parse_header(s):
    m = re.search(r"\{\{\s*Header(.*?)\}\}", s, re.S | re.I)
    if not m:
        return {}, s
    fields = {}
    for k, v in re.findall(r"\|\s*([\w]+)\s*=\s*([^|\n}]*)", m.group(1)):
        fields[k.strip().lower()] = v.strip()
    body = s[:m.start()] + s[m.end():]
    return fields, body


def clean(s):
    s = re.sub(r"<ref[^>]*>.*?</ref>", "", s, flags=re.S | re.I)
    s = re.sub(r"<!--.*?-->", "", s, flags=re.S)
    s = re.sub(r"\[\[File:[^\]]*\]\]", "", s, flags=re.I)
    s = re.sub(r"\[\[([^\]|]*)\|([^\]]*)\]\]", r"\2", s)
    s = re.sub(r"\[\[([^\]]*)\]\]", r"\1", s)
    s = re.sub(r"\{\{[^{}]*\}\}", "", s)
    s = re.sub(r"<[^>]+>", "", s)
    s = re.sub(r"'{2,}", "", s)
    s = re.sub(r"^\s*[-—=]{3,}.*$", "", s, flags=re.M)
    lines = []
    for ln in s.splitlines():
        ln = ln.strip()
        if not ln:
            lines.append("")
            continue
        # 去掉页脚的刊物出处行、页码、注释标记
        if re.match(r"^\d{4}年\d{1,2}月\d{1,2}日《", ln):
            continue
        if re.match(r"^〔?注[釋释]?〕?", ln):
            continue
        if re.fullmatch(r"[\d\s\(\)（）]+", ln):
            continue
        lines.append(ln)
    out = "\n".join(lines)
    out = re.sub(r"\n{3,}", "\n\n", out).strip()
    return out


def paras(s):
    return [p.strip() for p in re.split(r"\n\s*\n", s) if len(p.strip()) >= 12]


ALIAS = {"漢俊": "李漢俊", "漢俊?": "李漢俊", "獨秀": "陳獨秀",
         "陳獨秀": "陳獨秀", "魯迅": "魯迅", "唐俟": "魯迅(唐俟)"}


def author_from_title(t):
    m = re.search(r"[（(]([^（）()]{1,8})[）)]\s*$", t)
    if not m:
        return ""
    a = m.group(1).strip()
    return ALIAS.get(a, a)


docs = []

# ---------- A. 《热风》「隨感錄」单篇 ----------
with open(os.path.join(ROOT, "ap_refeng.json"), encoding="utf-8") as f:
    refeng = [x["title"] for x in json.load(f)["query"]["allpages"]]
refeng = [t for t in refeng if re.search(r"熱風/隨感錄/", t)]
NUM = {"二十五": 25, "三十三": 33, "三十九": 39, "三十五": 35, "三十八": 38,
       "三十六": 36, "五十七": 57, "五十三": 53, "五十九": 59, "五十八": 58,
       "五十六": 56, "五十四": 54, "六十一": 61, "六十三": 63, "六十二": 62,
       "六十五": 65, "六十六": 66, "六十四": 64, "四十": 40, "四十一": 41,
       "四十七": 47, "四十三": 43, "四十九": 49, "四十二": 42, "四十八": 48,
       "四十六": 46}


def cn2int(s):
    if s in NUM:
        return NUM[s]
    d = {"一": 1, "二": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7,
         "八": 8, "九": 9, "十": 10}
    if s.startswith("五十"):
        return 50 + d.get(s[2:], 0)
    if s.startswith("六十"):
        return 60 + d.get(s[2:], 0)
    if s.startswith("四十"):
        return 40 + d.get(s[2:], 0)
    if s.startswith("三十"):
        return 30 + d.get(s[2:], 0)
    return 0


refeng.sort(key=lambda t: cn2int(t.rsplit("/", 1)[-1]))
for i, title in enumerate(refeng, 1):
    sec = title.rsplit("/", 1)[-1]
    raw = fetch(title, "refeng_%02d" % i)
    hdr, body = parse_header(raw)
    body = clean(body)
    ps = paras(body)
    if not ps:
        LOG.append("EMPTY: " + title)
        continue
    y = hdr.get("year", "")
    mo = hdr.get("month", "")
    da = hdr.get("day", "")
    docs.append({
        "id": "A%02d" % i,
        "title": "隨感錄·" + sec,
        "author": hdr.get("author", "魯迅"),
        "date": ("%s-%s-%s" % (y, mo.zfill(2), da.zfill(2))) if y else "",
        "year": int(y) if y.isdigit() else 0,
        "source_type": "结集重收本（《热风》）",
        "source_page": title,
        "source_note": hdr.get("notes", "").replace("'''", ""),
        "text": "\n\n".join(ps),
        "n_paras": len(ps),
        "n_chars": sum(len(p) for p in ps),
    })

# ---------- B. 《新青年》原刊页（按小标题拆则） ----------
XQN = ["新青年/第07卷/第1號/隨感錄",
       "新青年/第07卷/第2號/隨感錄",
       "新青年/第09卷/第1號/隨感錄"]
for j, title in enumerate(XQN, 1):
    raw = fetch(title, "xqn_%02d" % j)
    hdr, body = parse_header(raw)
    body = clean(body)
    parts = re.split(r"^==+\s*(.+?)\s*==+\s*$", body, flags=re.M)
    # parts[0] 为标题前内容，随后成对出现 (标题, 正文)
    for k in range(1, len(parts), 2):
        ttl = parts[k].strip()
        txt = clean(parts[k + 1]) if k + 1 < len(parts) else ""
        ps = paras(txt)
        if not ps:
            LOG.append("EMPTY SECTION: %s / %s" % (title, ttl))
            continue
        a = author_from_title(ttl) or hdr.get("author", "")
        y = hdr.get("year", "")
        mo = hdr.get("month", "")
        da = hdr.get("day", "")
        docs.append({
            "id": "B%02d" % (len([d for d in docs if d["id"].startswith("B")]) + 1),
            "title": re.sub(r"[（(][^（）()]{1,8}[）)]\s*$", "", ttl).strip(),
            "author": a,
            "date": ("%s-%s-%s" % (y, mo.zfill(2), da.zfill(2))) if y else "",
            "year": int(y) if y.isdigit() else 0,
            "source_type": "期刊原刊页（《新青年》）",
            "source_page": title,
            "source_note": "原标题署名：" + (author_from_title(ttl) or "未标"),
            "text": "\n\n".join(ps),
            "n_paras": len(ps),
            "n_chars": sum(len(p) for p in ps),
        })

# ---------- 输出 ----------
with open(os.path.join(ROOT, "corpus.jsonl"), "w", encoding="utf-8") as f:
    for d in docs:
        f.write(json.dumps(d, ensure_ascii=False) + "\n")
with open(os.path.join(ROOT, "corpus_manifest.csv"), "w", encoding="utf-8-sig", newline="") as f:
    w = csv.writer(f)
    w.writerow(["编号", "篇题", "作者", "刊行日期", "年份", "来源类型", "维基文库条目", "段数", "字数", "备注"])
    for d in docs:
        w.writerow([d["id"], d["title"], d["author"], d["date"], d["year"],
                    d["source_type"], d["source_page"], d["n_paras"], d["n_chars"], d["source_note"]])

report = {
    "n_docs": len(docs),
    "authors": {},
    "years": {},
    "types": {},
    "total_chars": sum(d["n_chars"] for d in docs),
    "min_chars": min(d["n_chars"] for d in docs),
    "max_chars": max(d["n_chars"] for d in docs),
    "log": LOG,
}
for d in docs:
    report["authors"][d["author"]] = report["authors"].get(d["author"], 0) + 1
    report["years"][str(d["year"])] = report["years"].get(str(d["year"]), 0) + 1
    report["types"][d["source_type"]] = report["types"].get(d["source_type"], 0) + 1
with open(os.path.join(ROOT, "corpus_report.json"), "w", encoding="utf-8") as f:
    json.dump(report, f, ensure_ascii=False, indent=2)
print(json.dumps(report, ensure_ascii=False, indent=2))
