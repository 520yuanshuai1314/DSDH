# -*- coding: utf-8 -*-
"""交叉验证：用 scikit-learn 变分 EM 实现重跑基准组 LDA，与自实现 Gibbs 采样比对。"""
import json
import os
import re

import jieba
from opencc import OpenCC
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.feature_extraction.text import CountVectorizer

ROOT = r"D:\2026-11-12-15-41-12"
SEED = 20261112
r = json.load(open(os.path.join(ROOT, "results.json"), encoding="utf-8"))
generic = set(r["rules"]["generic_stop"])
specific = set(r["rules"]["specific_stop"])
for w in r["rules"]["user_words"]:
    jieba.add_word(w, freq=2000)
cc = OpenCC("t2s")
docs = [json.loads(l) for l in open(os.path.join(ROOT, "corpus.jsonl"), encoding="utf-8")]

texts = []
for d in docs:
    toks = []
    for raw in jieba.cut(cc.convert(d["text"])):
        w = raw.strip().lower()
        if not w or re.match(r"^[\W\d_]+$", w) or len(w) < 2:
            continue
        if w in generic or w in specific:
            continue
        toks.append(w)
    texts.append(" ".join(toks))

cv = CountVectorizer(min_df=2, token_pattern=r"(?u)\b\w+\b")
X = cv.fit_transform(texts)
names = cv.get_feature_names_out()
model = LatentDirichletAllocation(
    n_components=4, learning_method="batch", max_iter=500,
    doc_topic_prior=0.1, topic_word_prior=0.01,
    random_state=SEED, evaluate_every=-1)
model.fit(X)

topics = []
for k, comp in enumerate(model.components_):
    idx = comp.argsort()[::-1][:12]
    topics.append([{"word": names[j], "weight": round(float(comp[j] / comp.sum()), 6)} for j in idx])
print("sklearn topics:")
for k, t in enumerate(topics):
    print("  S%d" % (k + 1), " ".join(x["word"] for x in t[:10]))

gibbs = r["groups"][0]["lda"]["topics"]


def jac(a, b):
    sa, sb = set(a), set(b)
    return len(sa & sb) / len(sa | sb) if sa | sb else 0.0


match = []
for k, t in enumerate(topics):
    sw = [x["word"] for x in t[:10]]
    best = max(((jac(sw, [x["word"] for x in g[:10]]), j) for j, g in enumerate(gibbs)))
    match.append({"sk_topic": k, "gibbs_topic": best[1], "jaccard": round(best[0], 3),
                  "words": sw})
print("matches:", [(m["sk_topic"], m["gibbs_topic"], m["jaccard"]) for m in match])

out = {"engine": "scikit-learn 1.9.1 LatentDirichletAllocation (batch variational EM)",
       "params": {"n_components": 4, "max_iter": 500, "doc_topic_prior": 0.1,
                  "topic_word_prior": 0.01, "random_state": SEED, "min_df": 2},
       "n_docs": len(texts), "vocab_size": len(names), "topics": topics, "match": match}
with open(os.path.join(ROOT, "crosscheck.json"), "w", encoding="utf-8") as f:
    json.dump(out, f, ensure_ascii=False, indent=2)
print("WROTE crosscheck.json")
